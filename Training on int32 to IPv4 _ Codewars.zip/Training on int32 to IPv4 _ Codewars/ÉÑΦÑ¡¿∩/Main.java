import javax.swing.*;

public class Main {
    public static void main(String[] args) {

        System.out.println ("================================== Try 1) =================================" );
        System.out.println ( );
        System.out.println (toIP ( 2149583361l ) );
        System.out.println ( );
        System.out.println ("==============================================================================" );
        System.out.println ( );
        System.out.println ( );
        System.out.println ("================================== Try 2) =================================" );
        System.out.println ( );
        int [] data = {32, 1233, Integer.MAX_VALUE, Integer.MIN_VALUE, 192<<24|156<<16|5};
        for (int d : data) {
            System.out.println(toIP(d));
            System.out.println(toPaddedBinary(d));
            System.out.println();
        }
        System.out.println ("==============================================================================" );
        System.out.println ( );
        System.out.println ( );
        System.out.println ("================================== Try 3) =================================" );
        System.out.println (toIP ( 2154959208L ) );
       // "128.114.17.104"

        System.out.println ( );
        System.out.println ("==============================================================================" );
    }

    public static String toIP(long ip) {
        String ip1 = Integer.toString((int) (ip >> 24 & 0xFF)) + ".";
        ip1 += Integer.toString((int) ((ip >> 16) & 0xFF)) + ".";
        ip1 += Integer.toString((int) ((ip >> 8) & 0xFF)) + ".";
        ip1 += Integer.toString((int) (ip & 0xFF));
        return ip1;
    }

    public static String toPaddedBinary(int v) {
        long x = (v|(1L<<32))&0x1FFFFFFFFL;
        return Long.toBinaryString(x).substring(1);
    }
}